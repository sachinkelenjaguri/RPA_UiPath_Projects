# UiPath-Advanced-Training-Assignment-2

This repository contains solution for Level 3 Advanced Training Assignment 2 by UiPath Academy.
